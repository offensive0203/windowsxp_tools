<?php
    $languages['en'] = "English";
    $languages['de'] = "Deutsch";
    $languages['fr'] = "Francais";
    $languages['nl'] = "Nederlands";
    $languages['pl'] = "Polski";
    $languages['sl'] = "Slovene";
    $languages['it'] = "Italiano";
    $languages['no'] = "Norsk";
    $languages['es'] = "Espa&ntilde;ol";
    $languages['zh'] = "&#20013;&#25991;";
    $languages['pt'] = "Portugu&ecirc;s";
    $languages['pt_br'] = "Portugu&ecirc;s (Brasil)";
    $languages['jp'] = "&#26085;&#26412;&#35486;";
?>
